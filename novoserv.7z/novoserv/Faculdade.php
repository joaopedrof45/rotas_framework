<?php


class Faculdade
{
    public function index()
    {
        echo 'Index faculdade';
    }

    public function insere()
    {
        echo 'Faz a inserção faculdade';
    }
}