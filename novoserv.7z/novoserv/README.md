# aula23-10
Implementação do exemplo de algoritmo do componente de orquestrador do sistema
