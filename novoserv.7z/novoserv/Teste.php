<?php


class Teste
{
    public function index()
    {
        echo 'Metodo padrão';
    }

    public function entrada2()
    {
        echo 'Metodo entrada 2';
    }
}