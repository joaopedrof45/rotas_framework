<?php


class Aluno
{
    public function index()
    {
        echo 'Lista Teste Teste';
    }

    public function cpa()
    {
        echo 'cpa';
    }   
}